#con esta función puedo entregar informacion a los usuarios
print("Hola este es mi primer mensaje")  

#algunos tipos de datos son númericos
numero=20
decimal=3.14
#otros son de tipo texto
texto="tengo la siguiente edad:"
ciudad="Valdivia"
#puedo concatenar texto y un número, pero debo realizar una conversión para juntarlos
print(texto+str(numero))   

#podemos interpolar variables entre el texto
print(f"mi edad es {numero} , y vivo en chile en {ciudad}")

# este es un comentario simple

'''
este es
un comentario
de multiples líneas
'''

"""
este también es
un comentario de muchas 
líneas
"""

# otro tipo de dato es el boolean






